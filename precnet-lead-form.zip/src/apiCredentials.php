<?php 
if (!defined('ABSPATH')) exit;

$token = 'Bearer ca157b7acc070f9f77c3ce0a307bac67fe01647d4e6def126dee153135a66594';
$apiBase = 'https://precnet.pythonanywhere.com/api/v1/';
