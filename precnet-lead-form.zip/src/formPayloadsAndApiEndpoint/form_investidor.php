<?php 
if (!defined( 'ABSPATH')) exit;

//values of fields coming from parent send-lead-to-api.php 
$apiEndpoint = 'forms/investidor';

$payload = [
    'name' => sanitize_text_field($_POST['name']),
    'phone' => sanitize_text_field($_POST['phone']),
    'email' => sanitize_email($_POST['email']),
    'origin' => 'formulario_home_investidor'
];