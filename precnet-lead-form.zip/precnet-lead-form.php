<?php 
/**
 * Plugin Name: Precnet Lead Form
 * Description: Envia os leads do formulário para a API
 * Plugin URI:  https://github.com/lucassdantas/wp_precnet-investidor-lead-sender
 * Version:     1.0.0
 * Author:      RD Exclusive
 * Author URI:  https://www.rdexclusive.com.br
 */

if (!defined('ABSPATH')) exit;
if (!function_exists('add_action')) die;

if (!defined('ABSPATH')) exit;

// Shortcode para renderizar o formulário
add_shortcode('precnet_lead_form', 'precnet_render_lead_form');

function precnet_render_lead_form() {
    ob_start(); ?>
    <form id="precnet-lead-form" class="precnet-lead-form">
        <div class="form-group">
            <label for="name">nome</label>
            <input type="text" id="name" name="name" placeholder="NOME" required>
        </div>

        <div class="form-group">
            <label for="phone">telefone</label>
            <input type="tel" id="phone" name="phone" placeholder="TELEFONE (COM DDD)" required>
        </div>

        <div class="form-group full-width">
            <label for="email">email</label>
            <input type="email" id="email" name="email" placeholder="EMAIL" required>
        </div>

        <label class="terms-label">
            <input type="checkbox" name="terms" required>
            Aceito os <a href="https://investidor.precnet.com.br/politica-de-privacidade/" target="_blank">termos</a> para uso de dados
        </label>

        <button type="submit">QUERO DESCOBRIR AGORA</button>

        <div id="precnet-lead-form-msg"></div>
    </form>
    <?php
    return ob_get_clean();
}


// Scripts
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('precnet-lead-form-css', plugin_dir_url(__FILE__) . 'css/lead-form.css');
    wp_enqueue_script('precnet-lead-form-js', plugin_dir_url(__FILE__) . 'js/lead-form.js', ['jquery'], null, true);
    //wp_enqueue_script('precnet-lead-form-js', plugin_dir_url(__FILE__) . 'js/inputs-mask.js', null, true);
    wp_localize_script('precnet-lead-form-js', 'precnet_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
    ]);
});

// Handler AJAX (logged-in and non-logged-in users)
add_action('wp_ajax_precnet_send_lead', 'precnet_send_lead');
add_action('wp_ajax_nopriv_precnet_send_lead', 'precnet_send_lead');

function precnet_send_lead() {
    // Validação
    if (
        empty($_POST['name']) ||
        empty($_POST['phone']) ||
        empty($_POST['email']) ||
        empty($_POST['terms'])
    ) {
        wp_send_json_error('Todos os campos são obrigatórios.');
    }

    require_once plugin_dir_path(__FILE__) . 'src/apiCredentials.php';
    require_once plugin_dir_path(__FILE__) . 'src/formPayloadsAndApiEndpoint/form_investidor.php';

    $headers = [
        'Content-Type' => 'application/json',
        'Authorization' => $token,
    ];

    $response = wp_remote_post($apiBase . $apiEndpoint, [
        'headers' => $headers,
        'body' => json_encode($payload),
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error('Erro ao enviar. Tente novamente.');
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($status_code === 201) {
        wp_send_json_success([
            'message' => $body['message'],
            'redirect' => 'https://investidor.precnet.com.br/cadastro-realizado/',
        ]);
    } else {
        wp_send_json_error($body['message'] ?? 'Erro inesperado.');
    }
}
